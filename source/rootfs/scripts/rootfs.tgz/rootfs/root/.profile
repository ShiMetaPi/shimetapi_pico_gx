#!/bin/sh

nfsroot

