/*
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#include <stdio.h>  // printf
#include <stdlib.h> // free
#include <string.h> // memset, strcat, strlen
#include "zstd.h"   // presumes zstd library is installed
#include "common.h" // Helper functions, CHECK(), and CHECK_ZSTD()

int zstd_compress(char *input, int inlen, char *output, size_t outlen)
{
    /* Create the context. */
    ZSTD_CCtx *const cctx = ZSTD_createCCtx();
    CHECK(cctx != NULL, "ZSTD_createCCtx() failed!");
    /* Set any parameters you want.
     * Here we set the compression level, and enable the checksum.
     */
    CHECK_ZSTD(ZSTD_CCtx_setParameter(cctx, ZSTD_c_checksumFlag, 1));

    ZSTD_inBuffer input_buf = { input, inlen, 0 };
    ZSTD_outBuffer output_buf = { output, outlen, 0 };
    size_t const remaining =
        ZSTD_compressStream2(cctx, &output_buf, &input_buf, ZSTD_e_end);

    ZSTD_freeCCtx(cctx);
    if (remaining == 0) {
        return output_buf.pos;
    } else {
        return -2;
    }
}

int zstd_decompress(char *input, int inlen, char *output, size_t outlen)
{
    /* Create the context. */
    ZSTD_DCtx *const dctx = ZSTD_createDCtx();
    CHECK(dctx != NULL, "ZSTD_createDCtx() failed!");

    ZSTD_inBuffer input_buf = { input, inlen, 0 };
    ZSTD_outBuffer output_buf = { output, outlen, 0 };

    size_t const ret = ZSTD_decompressStream(dctx, &output_buf, &input_buf);
    ZSTD_freeDCtx(dctx);
    if (ret == 0) {
        return output_buf.pos;
    } else {
        return ret;
    }
}

//compress output size: if deflate outputsize = inputsize * 2 + 400,
//if zstd outputsize = inputsize + 4 + 3
int compress_media(char *input, int inlen, char *output, int outlen)
{
    int compressed_len = -1;

    compressed_len = zstd_compress(input, inlen, output, outlen);

    return compressed_len;
}

int decompress_media(char *input, int inlen, char *output, int outlen)
{
    int compress_len = -1;

    compress_len = zstd_decompress(input, inlen, output, outlen);

    return compress_len;
}
