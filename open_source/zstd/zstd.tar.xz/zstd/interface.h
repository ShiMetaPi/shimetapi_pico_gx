#ifndef XMEDIA_ZSTD_H
#define XMEDIA_ZSTD_H

#ifdef __cplusplus
extern "C" {
#endif

int compress_media(char *input, int inlen, char *output, int outlen);
int decompress_media(char *input, int inlen, char *output, int outlen);

#ifdef __cplusplus
}
#endif

#endif
