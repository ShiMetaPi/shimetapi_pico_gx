#!/bin/sh

set -e

HERE=`dirname $0`
cd $HERE/..
ROOT=`pwd`

CFGFILE=${ROOT}/scripts/build.cfg

if [ -e $CFGFILE ]; then
    . $CFGFILE
fi

#FLATCC_BUILD_CMD=${FLATCC_BUILD_CMD:-ninja}

mkdir -p ${ROOT}/bin
mkdir -p ${ROOT}/lib

rm -f ${ROOT}/bin/flatcc
rm -f ${ROOT}/libflatcc
rm -f ${ROOT}/libflatccrt.a

if [ ! -d  ${ROOT}/build/Release ]; then
    ${ROOT}/scripts/initbuild.sh
fi

echo "building Release" 1>&2
cd ${ROOT}/build/Release && $FLATCC_BUILD_CMD -j20
